<?php

namespace Database\Factories;

use Illuminate\Database\Eloquent\Factories\Factory;

class ProspectoTempFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array
     */
    public function definition()
    {
        return [
            'name' => $this->faker->name(),
            'last_name' => $this->faker->last_name(),
            'document' => rand(10000, 9999999999),
            'ciudad_c' => $this->faker->ciudad_c(),
            'phone_mobile' => $this->faker->numerify('###-###-####'),
            'email' => $this->faker->unique()->safeMail(),
            'medio' => $this->faker->medio(),
            'datetime' => now(),
            'facebook_forms_c' => 1212121212121212,
            'validated' => 0

        ];
    }
}

<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class LeadsController extends Controller
{
    public function index()
    {
        return 'Método ejecutado con éxito...';
    }
}
